This firmware was obtained via Anycubic Support. If your printer is working well, DO NOT update the firmware. Use this at your own risk. 

Fixes unresponsive Z axis, dead fans, no UV, low contrast LCD. 

Instructions :

1. Format a known good USB stick to FAT32. 

2. Copy the 4 files (excluding this readme.txt) to the USB root folder. 

3. Make sure your printer is switched off. 

4. Insert USB stick. 

5. Switch on printer. 

The update.lcd file will then update the firmware and the printer starts. 

6. Now navigate the touchscreen menu and select and "print" the other 3 files one by one in sequence:

fpga26_V22_99

导出状态文件.txt

机器参数.gcode



Original FB post: https://www.facebook.com/groups/AnycubicPhoton/permalink/1479964245481546/

Kudos: Curtis Miller. 
Zip and instructions by Sen Kun. 