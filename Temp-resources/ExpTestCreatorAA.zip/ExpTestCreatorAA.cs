using System;
using System.IO;
using System.Runtime.InteropServices;
using System.Text.RegularExpressions;

public class Extractor
{
		private static uint SPI_FILE_MAGIC_BASE = 0x12FD0000;
		private byte[] fileDat = new byte[0];
		private static int V2_ADDITIONAL_HEADER_SIZE = 4;
		private static int V2_PARAMETERS_SIZE = 60;

		[StructLayout(LayoutKind.Sequential, Pack = 1)]
		public struct cbddlp_file_head_t
		{
			public int magic;
			public int version;
			public float bedXmm;
			public float bedYmm;
			public float bedZmm;
			public int unknown1;
			public int unknown2;
			public int unknown3;
			public float layerHeightMilimeter;
			public float exposureTimeSeconds;
			public float exposureBottomTimeSeconds;
			public float offTimeSeconds;
			public int bottomLayers;
			public int resolutionX;
			public int resolutionY;
			public int previewOneOffsetAddress;
			public int layersDefinitionOffsetAddress;
			public int numberOfLayers;
			public int previewTwoOffsetAddress;
			public int printTime;
			public int projectType;
			public int printParametersOffsetAddress;
			public int printParametersSize;
			public int antiAliasingLevel;
			public short lightPWM;
			public short bottomLightPWM;
			public int padding1;
			public int padding2;
			public int padding3;
		}

		[StructLayout(LayoutKind.Sequential, Pack = 1)]
		public struct print_parameters_t
		{
			public float bottomLiftDistance;
			public float bottomLiftSpeed;
			public float liftingDistance;
			public float liftingSpeed;
			public float retractSpeed;
			public float VolumeMl;
			public float WeightG;
			public float CostDollars;
			public float BottomLightOffDelay;
			public float lightOffDelay;
			public int bottomLayerCount;
			public float P1;
			public float P2;
			public float P3;
			public float P4;
		}

		[StructLayout(LayoutKind.Sequential, Pack = 1)]
		public struct layer_definition_t
		{
			public float layerPositionZ;
			public float layerExposure;
			public float layerOffTimeSeconds;
			public int dataAddress;
			public int dataSize;
			public int unknown1;
			public int unknown2;
			public int unknown3;
			public int unknown4;
		}

		public byte[] StructToBytes(object obj)
		{
			int num = Marshal.SizeOf(obj);
			IntPtr intPtr = Marshal.AllocHGlobal(num);
			Marshal.StructureToPtr(obj, intPtr, false);
			byte[] array = new byte[num];
			Marshal.Copy(intPtr, array, 0, num);
			Marshal.FreeHGlobal(intPtr);
			return array;
		}

		public object BytesToStruct(byte[] buf, int len, Type type)
		{
			IntPtr intPtr = Marshal.AllocHGlobal(len);
			Marshal.Copy(buf, 0, intPtr, len);
			object result = Marshal.PtrToStructure(intPtr, type);
			Marshal.FreeHGlobal(intPtr);
			return result;
		}

		public object BytesToStruct(byte[] buf, Type type)
		{
			return BytesToStruct(buf, buf.Length, type);
		}

		public int CreateFile(string InFile, int AA)
		{
			StreamReader streamReader;
			try
			{
				streamReader = new StreamReader(InFile);
			}
			catch (Exception)
			{
				System.Console.WriteLine("Unable to open CBDDLP file:" + InFile);
				return -1;
			}
			FileInfo fileInfo = new FileInfo(InFile);
			fileDat = new byte[fileInfo.Length];
			streamReader.BaseStream.Read(fileDat, 0, fileDat.Length);
			streamReader.Close();
			cbddlp_file_head_t old_file_head = default(cbddlp_file_head_t);
			byte[] array = new byte[Marshal.SizeOf((object)old_file_head)];
			Buffer.BlockCopy(fileDat, 0, array, 0, Marshal.SizeOf((object)old_file_head));
			old_file_head = (cbddlp_file_head_t)BytesToStruct(array, Marshal.SizeOf((object)old_file_head), old_file_head.GetType());
			if (old_file_head.magic == (SPI_FILE_MAGIC_BASE | 0x19))
			{
				//Check AA level and version. Only V1 with no AA supported.
				if ((old_file_head.version != 1) || (old_file_head.antiAliasingLevel >1))
				{
					System.Console.WriteLine("Invalid CBDDLP file:" + InFile + ". Only files without AA enabled (V1) are supported.");
					return -1;
				}
				//Number of layers must be multiple of desired AA level
				if ((old_file_head.bottomLayers % AA) != 0)
				{
					System.Console.WriteLine("Invalid CBDDLP file:" + InFile + ". Must have multiple of {0} bottom layers!", AA);
					return -1;
				}
				if ((old_file_head.numberOfLayers % AA) != 0)
				{
					System.Console.WriteLine("Invalid CBDDLP file:" + InFile + ". Must have multiple of {0} layers!", AA);
					return -1;
				}

				//Read the source file layer definitions
				int numLayers = old_file_head.numberOfLayers;
				layer_definition_t[] oldLayerArray = new layer_definition_t[numLayers];
				layer_definition_t old_layer_definition = default(layer_definition_t);
				byte[] array3 = new byte[Marshal.SizeOf((object)old_layer_definition)];
				int layerOffset = old_file_head.layersDefinitionOffsetAddress;
				for (int layer=0; layer < numLayers; layer++)
				{
					Buffer.BlockCopy(fileDat, layerOffset, array3, 0, Marshal.SizeOf((object)old_layer_definition));
					old_layer_definition = (layer_definition_t)BytesToStruct(array3, Marshal.SizeOf((object)old_layer_definition), old_layer_definition.GetType());
					layerOffset +=  Marshal.SizeOf((object)old_layer_definition);
					oldLayerArray[layer] = old_layer_definition;
				}

				//Create V2 output file
				string directoryName = AppDomain.CurrentDomain.BaseDirectory;
				string text = directoryName + "\\" + "ExpTestAA.cbddlp";
				StreamWriter streamWriter;
				try
				{
					streamWriter = new StreamWriter(text);
				}
				catch (Exception)
				{
					System.Console.WriteLine("Unable to generate output file:" + text);
					return -1;
				}

				//To make the test we are going to convert a file with N layers and no AA to a file with N/AA layers and AA
				// so we need to also to update heights and number of layers/AAlevel

				//Update header with V2 format, new number of layers and AA level
				cbddlp_file_head_t new_header;
				new_header = old_file_head; //Copy old header
				//update fields
				new_header.version = 2;
				new_header.antiAliasingLevel = AA;
				new_header.bottomLayers = old_file_head.bottomLayers / AA;
				new_header.numberOfLayers = old_file_head.numberOfLayers / AA;
				new_header.previewOneOffsetAddress = old_file_head.previewOneOffsetAddress + V2_ADDITIONAL_HEADER_SIZE;
				new_header.layersDefinitionOffsetAddress = old_file_head.layersDefinitionOffsetAddress + V2_ADDITIONAL_HEADER_SIZE + V2_PARAMETERS_SIZE;
				new_header.previewTwoOffsetAddress = old_file_head.previewTwoOffsetAddress + V2_ADDITIONAL_HEADER_SIZE;
				new_header.printParametersOffsetAddress = old_file_head.layersDefinitionOffsetAddress + V2_ADDITIONAL_HEADER_SIZE;
				new_header.printParametersSize = V2_PARAMETERS_SIZE;
				new_header.lightPWM = 255;
				new_header.bottomLightPWM = 255;
				new_header.padding1 = 0;
				new_header.padding2 = 0;
				new_header.padding3 = 0;
				
				//Create print parameters
				print_parameters_t print_parameters = default (print_parameters_t);
				print_parameters.bottomLiftDistance = 5;
				print_parameters.bottomLiftSpeed = 300;
				print_parameters.liftingDistance = 5;
				print_parameters.liftingSpeed = 300;
				print_parameters.retractSpeed = 300;
				print_parameters.VolumeMl = 0;
				print_parameters.WeightG = 0;
				print_parameters.CostDollars = 0;
				print_parameters.BottomLightOffDelay = old_file_head.offTimeSeconds;
				print_parameters.lightOffDelay = old_file_head.offTimeSeconds;
				print_parameters.bottomLayerCount = new_header.bottomLayers;
				print_parameters.P1 = 0;
				print_parameters.P2 = 0;
				print_parameters.P3 = 0;
				print_parameters.P4 = 0;
				//Read the parameters file (if exists)
				string text2 = directoryName + "\\parameters.csv";
				StreamReader streamReader2;
				try
				{
					streamReader2 = new StreamReader(text2);
					string line;
					Regex parts = new Regex(@"^(\d+)\,(\d+)\,(\d+)\,(\d+)\,(\d+)");
					line = streamReader2.ReadLine(); //Discard first line
					if ((line = streamReader2.ReadLine()) != null)
					{
						Match match = parts.Match(line);
						if (match.Success)
						{
							print_parameters.bottomLiftDistance = float.Parse(match.Groups[1].Value);
							print_parameters.bottomLiftSpeed = float.Parse(match.Groups[2].Value);
							print_parameters.liftingDistance = float.Parse(match.Groups[3].Value);
							print_parameters.liftingSpeed = float.Parse(match.Groups[4].Value);
							print_parameters.retractSpeed = float.Parse(match.Groups[5].Value);
						}
					}
				}
				catch (Exception)
				{
					System.Console.WriteLine("No parameter file found:" + text2 + ".Using defaults.");
				}

				//Write header
				array = StructToBytes(new_header);
				streamWriter.BaseStream.Write(array, 0, array.Length);
				
				//Copy both preview files
				streamWriter.BaseStream.Write(fileDat, old_file_head.previewOneOffsetAddress, (old_file_head.layersDefinitionOffsetAddress-old_file_head.previewOneOffsetAddress));
				
				//Write parameters
				byte[] array2 = new byte[Marshal.SizeOf((object)print_parameters)];
				array2 = StructToBytes(print_parameters);
				streamWriter.BaseStream.Write(array2, 0, array2.Length);

				//Copy layer data
				streamWriter.BaseStream.Write(fileDat, old_file_head.layersDefinitionOffsetAddress, (fileDat.Length-old_file_head.layersDefinitionOffsetAddress));

				//Overwrite layer definitions: Set all the images within the same layer to values of first image data(AA images = 1 layer)
				streamWriter.BaseStream.Seek(new_header.layersDefinitionOffsetAddress, SeekOrigin.Begin);
				//Build the modified layer table
				//Need to reorder images into new layers and AA levels!!
				layer_definition_t modifiedLayer;
				for (int level=0; level<AA; level++)
				{
					for (int layer=0; layer < new_header.numberOfLayers; layer++)
					{
						//Keep address/size and take exposure/offTime from 1st image of the AA group, and Zpos from correct height image
						modifiedLayer.dataAddress = oldLayerArray[level+(AA*layer)].dataAddress;
						modifiedLayer.dataSize = oldLayerArray[level+(AA*layer)].dataSize;
						modifiedLayer.layerPositionZ = oldLayerArray[layer].layerPositionZ;
						modifiedLayer.layerExposure = oldLayerArray[AA*layer].layerExposure;
						modifiedLayer.layerOffTimeSeconds = oldLayerArray[AA*layer].layerOffTimeSeconds;
						//Set spares
						modifiedLayer.unknown1 = 0;
						modifiedLayer.unknown2 = 0;
						modifiedLayer.unknown3 = 0;
						modifiedLayer.unknown4 = 0;
						//Write modified layer definition
						array3 = StructToBytes(modifiedLayer);
						streamWriter.BaseStream.Write(array3, 0, array3.Length);
					}
				}
			streamWriter.Close();
			}
			else
			{
				System.Console.WriteLine("Not a CBDDLP file!");
				return -1;
			}
		return 0;
		}
}

class MainClass
{
		static int Main(string[] args)
		{
				int AAlevel;
				
				// Test if input arguments were supplied:
				if ((args.Length < 1) || (args.Length > 2))
				{
						System.Console.WriteLine("ExpTestCreatorAA v0.2");
						System.Console.WriteLine("Please enter CBDDLP/PHOTON V1 file.");
						System.Console.WriteLine("Optionally a number indicating AA level 2/4/8/16 (default is 8)");
						System.Console.WriteLine("Usage: ExpTestCreatorAA <input file> [AAlevel]");
						System.Console.WriteLine(" Converts a V1 file (no AA) to V2 file with AA");
						return 1;
				}

				if (args.Length == 2)
				{
					AAlevel = int.Parse(args[1]);
					if ((AAlevel != 2) && (AAlevel != 4) && (AAlevel != 8) && (AAlevel != 16))
					{
						System.Console.WriteLine("Usage: ExpTestCreatorAA <input file> [AAlevel]");
						System.Console.WriteLine("Antialiasing level must be 2 or 4 or 8 or 16!");
						return 1;
					}
				}
				else 
				{
					AAlevel=8;
					System.Console.WriteLine("Antialiasing level not specified, default is 8.");
				}
				
				// Generate output file with extracted info of input file.
				Extractor extractor = new Extractor();
				int result = extractor.CreateFile(args[0], AAlevel);
				if (result != 0)
				{
						System.Console.WriteLine("AA-based exposure test file cannot be created!");
						return 1;
				}
				else
						System.Console.WriteLine("AA-based exposure test file created.");

				return 0;
		}
}

