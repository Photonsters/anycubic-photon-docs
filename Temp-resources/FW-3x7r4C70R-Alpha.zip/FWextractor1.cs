using System;
using System.IO;
//using System.Windows.Media.Imaging;
using System.Runtime.InteropServices;
using System.Drawing;
using System.Drawing.Imaging;

public class Extractor
{
		private static uint FW_FILE_MAGIC_BASE = 0x3F2D3D44;
		private byte[] fileDat = new byte[0];

		[StructLayout(LayoutKind.Sequential, Pack = 1)]
		public struct fw_file_head_t
		{
			public uint magic_num;
			public byte mask;
		}

		public object BytesToStruct(byte[] buf, int len, Type type)
		{
			IntPtr intPtr = Marshal.AllocHGlobal(len);
			Marshal.Copy(buf, 0, intPtr, len);
			object result = Marshal.PtrToStructure(intPtr, type);
			Marshal.FreeHGlobal(intPtr);
			return result;
		}

		public object BytesToStruct(byte[] buf, Type type)
		{
			return BytesToStruct(buf, buf.Length, type);
		}


		public int ExtractFW(string InFile, string OutFile)
		{
			StreamReader streamReader;
			try
			{
				streamReader = new StreamReader(InFile);
			}
			catch (Exception)
			{
				System.Console.WriteLine("Unable to open FW file:" + InFile);
				return -1;
			}
			string text = AppDomain.CurrentDomain.BaseDirectory + "\\" + OutFile;
			StreamWriter streamWriter;
			try
			{
				streamWriter = new StreamWriter(text);
			}
			catch (Exception)
			{
				System.Console.WriteLine("Unable to generate output file:" + text);
				return -1;
			}
			FileInfo fileInfo = new FileInfo(InFile);
			fileDat = new byte[fileInfo.Length];
			streamReader.BaseStream.Read(fileDat, 0, fileDat.Length);
			streamReader.Close();
			fw_file_head_t fw_file_head_t = default(fw_file_head_t);
			byte[] array = new byte[Marshal.SizeOf((object)fw_file_head_t)];
			Buffer.BlockCopy(fileDat, 0, array, 0, Marshal.SizeOf((object)fw_file_head_t));
			fw_file_head_t = (fw_file_head_t)BytesToStruct(array, Marshal.SizeOf((object)fw_file_head_t), fw_file_head_t.GetType());
			if (fw_file_head_t.magic_num == FW_FILE_MAGIC_BASE )
			{
				byte mask_value = fw_file_head_t.mask;
				byte[] data = new byte[1];
				for (int i=4; i<fileDat.Length; i++)
				{
					data[0] = (byte)(fileDat[i] ^ mask_value);
					streamWriter.BaseStream.Write(data, 0, 1);
				}
			}
			else
			{
				System.Console.WriteLine("Invalid FW file!");
				return -1;
			}
			return 0;
		}
}

class MainClass
{
    static int Main(string[] args)
    {
        // Test if input arguments were supplied:
        if (args.Length < 2)
        {
            System.Console.WriteLine("Please enter binary FW package and output file name.");
            System.Console.WriteLine("Usage: FWextractor <input FW binary> <output file>");
            return 1;
        }

        // Get the images.
        Extractor extractor = new Extractor();
        int result = extractor.ExtractFW(args[0], args[1]);
        if (result == 0)
        {
            System.Console.WriteLine("FW extracted");
            return 0;
        }
        else
        {
            System.Console.WriteLine("FW extraction failed!");
            return 1;
        }
    }
}

