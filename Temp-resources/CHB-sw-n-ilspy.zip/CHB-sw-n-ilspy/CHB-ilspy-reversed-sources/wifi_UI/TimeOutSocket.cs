using System;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace wifi_UI
{
	internal class TimeOutSocket
	{
		private static bool IsConnectionSuccessful = false;

		private static Exception socketexception;

		private static ManualResetEvent TimeoutObject = new ManualResetEvent(false);

		public static TcpClient Connect(IPEndPoint remoteEndPoint, int timeoutMSec)
		{
			TimeoutObject.Reset();
			socketexception = null;
			string host = Convert.ToString(remoteEndPoint.Address);
			int port = remoteEndPoint.Port;
			TcpClient tcpClient = new TcpClient();
			tcpClient.BeginConnect(host, port, CallBackMethod, tcpClient);
			if (TimeoutObject.WaitOne(timeoutMSec, false))
			{
				if (IsConnectionSuccessful)
				{
					return tcpClient;
				}
				throw socketexception;
			}
			tcpClient.Close();
			throw new TimeoutException("TimeOut Exception");
		}

		private static void CallBackMethod(IAsyncResult asyncresult)
		{
			try
			{
				IsConnectionSuccessful = false;
				TcpClient tcpClient = asyncresult.AsyncState as TcpClient;
				if (tcpClient.Client != null)
				{
					tcpClient.EndConnect(asyncresult);
					IsConnectionSuccessful = true;
				}
			}
			catch (Exception ex)
			{
				IsConnectionSuccessful = false;
				socketexception = ex;
			}
			finally
			{
				TimeoutObject.Set();
			}
		}
	}
}
