using System.Windows.Controls;

namespace wifi_UI
{
	internal class ImageButton : Button
	{
		private string m_imagepath;

		public string ImgPath
		{
			get
			{
				return m_imagepath;
			}
			set
			{
				m_imagepath = value;
			}
		}
	}
}
