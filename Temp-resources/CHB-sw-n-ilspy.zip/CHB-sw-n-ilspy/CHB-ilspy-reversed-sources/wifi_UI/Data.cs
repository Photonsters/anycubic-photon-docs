namespace wifi_UI
{
	internal class Data
	{
		public string name
		{
			get;
			set;
		}

		public int index
		{
			get;
			set;
		}

		public float kbps
		{
			get;
			set;
		}

		public Data()
		{
			name = "none";
			index = 0;
			kbps = 0f;
		}

		public Data(string name, int index, float kbps)
		{
			this.name = name;
			this.index = index;
			this.kbps = kbps;
		}
	}
}
