using System.Windows.Controls;

namespace wifi_UI
{
	internal class ImageLabel : Label
	{
		private string m_imagepath;

		public string ImgPath
		{
			get
			{
				return m_imagepath;
			}
			set
			{
				m_imagepath = value;
			}
		}
	}
}
