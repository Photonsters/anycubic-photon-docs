using Microsoft.Win32;
using System;
using System.CodeDom.Compiler;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Management;
using System.Net;
using System.Net.Sockets;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media.Imaging;

namespace wifi_UI
{
	public class MainWindow : Window, IComponentConnector
	{
		private class myFileCompare : IComparer
		{
			public int Compare(object x, object y)
			{
				Hashtable hashtable = (Hashtable)x;
				Hashtable hashtable2 = (Hashtable)y;
				return string.Compare((string)hashtable["name"], (string)hashtable2["name"]);
			}
		}

		private bool ENABLE_DEBUG_INFO = true;

		private float x_mm_per_step = 0.0127f;

		private float y_mm_per_step = 0.0127f;

		private float z_mm_per_step = 0.0127f;

		private float e_mm_per_step = 0.0127f;

		private int s_machine_type;

		private int s_x_max;

		private int s_y_max;

		private int s_z_max;

		private Thread threadRoutine;

		private Thread threadConnectIP;

		private Thread threadScan;

		private string remoteIPAddress = "";

		private string wifiFirmwareVersion = "";

		private bool stop = true;

		private UdpClient udpClient;

		private StreamWriter outStream;

		private StreamReader reader;

		private NetworkStream ns;

		private Queue<string> cmdQueue = new Queue<string>();

		private Queue<byte[]> datQueue = new Queue<byte[]>();

		private bool bLangEn;

		private bool bSendingFileFromLocal;

		private int SDFileReadAlready;

		private bool fileOpendFlag;

		private bool bLoadFromFromLocal;

		private ArrayList device_file_list_dat;

		private bool cmd_appending;

		private string ip = "192.168.1.122";

		private string versionNum = "V0.0.0";

		private FileStream target_local_file_fi;

		private FileStream saved_local_file_fi;

		private string saved_local_file_name = "";

		private uint saved_local_file_length;

		private uint saved_local_file_index;

		private int resend_index = -1;

		private Encoding ec = Encoding.GetEncoding("GBK");

		private Encoding ec_utf8 = Encoding.GetEncoding("utf-8");

		private double move_distance = 10.0;

		private bool stopCurrentFlag;

		private int CONNECTION_UNLINK;

		private int CONNECTION_WARN = 1;

		private int CONNECTION_LINK = 2;

		private bool timeoutFlag;

		private bool last_stop;

		private bool last_fileOpenFlag;

		private bool temp_fileOpenFlag;

		private int lastConnectionStatus;

		private int currentConnectionStatus;

		private bool debugVerbose = true;

		private bool wifiModuleAuthoFlag = true;

		private string targetSendFileName = "";

		private string deviceSelectedFileName = "  ";

		private int filePauseFlag = -1;

		private WindowState ws;

		private WindowState wsl;

		private NotifyIcon notifyIcon;

		private int dbgInfoIndex = 1;

		internal TextBlock textBlockMachineInfo;

		internal TextBlock textCoordination;

		internal TextBlock textTemperation;

		internal TextBlock textBlockInfo;

		internal TextBlock textBlockIPAddress;

		internal System.Windows.Controls.Image imageIndicator;

		internal System.Windows.Controls.GroupBox groupBox1;

		internal System.Windows.Controls.TextBox textBoxDbgInfo;

		internal ImageButton buttonSendCode;

		internal System.Windows.Controls.CheckBox checkBoxVerbose;

		internal ImageButton buttonClearDebugInfo;

		internal System.Windows.Controls.ComboBox comboBoxDebugCode;

		internal System.Windows.Controls.GroupBox groupBox3;

		internal ImageButton buttonTcpConnect;

		internal ImageButton buttonTcpDisconnect;

		internal System.Windows.Controls.Label label10;

		internal ImageButton buttonScanIP;

		internal System.Windows.Controls.ComboBox comboBoxIPAddress;

		internal System.Windows.Controls.ComboBox comboBoxLocalIP;

		internal System.Windows.Controls.Label label12;

		internal System.Windows.Controls.GroupBox groupBox4;

		internal ImageButton buttonRefresh;

		internal ImageButton buttonPause;

		internal ImageButton buttonStop;

		internal ImageButton buttonResume;

		internal System.Windows.Controls.ListView listViewFileList;

		internal ImageButton buttonPrint;

		internal ImageButton buttonDelete;

		internal TextBlock textBlockFileProgress;

		internal ImageButton buttonSendFile;

		internal System.Windows.Controls.CheckBox checkBoxCompressBeforeSend;

		internal ImageButton buttonExport;

		internal System.Windows.Controls.GroupBox 手动;

		internal ImageButton button_Y_plus;

		internal ImageButton button_E_plus;

		internal ImageButton button_Z_minus;

		internal ImageButton button_X_minus;

		internal ImageButton button_home;

		internal ImageButton button_X_plus;

		internal ImageButton button_E_minus;

		internal ImageButton button_Y_minus;

		internal ImageButton button_Z_plus;

		internal ImageButton button_10_mm;

		internal ImageButton button_1_mm;

		internal ImageButton button_0_1_mm;

		internal Slider sliderEndTemp;

		internal ImageLabel label1;

		internal TextBlock textBlockEndTemp;

		internal ImageLabel label2;

		internal TextBlock textBlockFanRatio;

		internal Slider sliderFanRatio;

		internal Slider sliderBedTemp;

		internal ImageLabel label3;

		internal TextBlock textBlockBedTemp;

		internal ImageButton buttonEmergencyStop;

		internal ImageButton buttonCloseDevice;

		internal ImageButton buttonHelp;

		internal System.Windows.Controls.GroupBox groupBox2;

		internal ImageLabel label5;

		internal ImageLabel label6;

		internal ImageLabel label8;

		internal ImageLabel label9;

		internal System.Windows.Controls.TextBox textBoxLoacalSSid;

		internal PasswordBox textBoxLoacalSSidPassword;

		internal System.Windows.Controls.TextBox textBoxRouterSSid;

		internal PasswordBox textBoxRouterSSidPassword;

		internal ImageButton buttonSetWifiHot;

		internal ImageButton buttonGenWifiHotConfig;

		internal ImageButton buttonSetRouterWifi;

		internal ImageButton buttonGenRouterWifiConfig;

		internal ImageLabel label13;

		internal System.Windows.Controls.TextBox textBoxDeviceName;

		internal ImageButton buttonDeviceNameSet;

		internal ImageLabel labelAuth;

		internal System.Windows.Controls.TextBox textBoxAuth;

		internal ImageButton buttonSetAuth;

		private bool _contentLoaded;

		public MainWindow()
		{
			InitializeComponent();
			rebindMoveButton();
			threadNotifyConnectionStatus(CONNECTION_UNLINK);
			setAuthButtonValid(false);
			handButtonEnable(false);
			base.ResizeMode = ResizeMode.NoResize;
			try
			{
				ManagementClass managementClass = new ManagementClass("Win32_NetworkAdapterConfiguration");
				ManagementObjectCollection instances = managementClass.GetInstances();
				foreach (ManagementObject item in instances)
				{
					if (Convert.ToBoolean(item["ipEnabled"]))
					{
						string text = (item["IPAddress"] as string[])[0];
						if (text.Length > 2 && !text.Substring(text.Length - 2).EndsWith(".1"))
						{
							comboBoxLocalIP.Text = text + "/" + (item["IPSubnet"] as string[])[0];
						}
						comboBoxLocalIP.Items.Add(text + "/" + (item["IPSubnet"] as string[])[0]);
					}
				}
			}
			catch (Exception)
			{
			}
			string[] array = distillLines("常用命令.txt");
			if (array != null)
			{
				string[] array2 = array;
				foreach (string text2 in array2)
				{
					comboBoxDebugCode.Items.Add(text2.Replace("\r", "").Replace("\n", ""));
				}
			}
			sliderEndTemp.AddHandler(UIElement.MouseLeftButtonUpEvent, new MouseButtonEventHandler(sliderEndTemp_MouseLeftButtonUp), true);
			sliderBedTemp.AddHandler(UIElement.MouseLeftButtonUpEvent, new MouseButtonEventHandler(sliderBedTemp_MouseLeftButtonUp), true);
			sliderFanRatio.AddHandler(UIElement.MouseLeftButtonUpEvent, new MouseButtonEventHandler(sliderFanRatio_MouseLeftButtonUp), true);
			buttonScanIP_Click(null, null);
			if (!ENABLE_DEBUG_INFO)
			{
				debugVerbose = false;
				checkBoxVerbose.Visibility = Visibility.Hidden;
			}
			if (!File.Exists("ChiTu HB软件说明.pdf") || !File.Exists("VC_compress_gcode.exe"))
			{
				System.Windows.MessageBox.Show("文件缺失，程序可能运行不正常", "警告", MessageBoxButton.OK, MessageBoxImage.Exclamation);
			}
			icon();
			wsl = base.WindowState;
		}

		private void icon()
		{
			notifyIcon = new NotifyIcon();
			notifyIcon.BalloonTipText = "ChiTu HB";
			notifyIcon.Text = "ChiTu HB";
			Icon icon3 = notifyIcon.Icon = (notifyIcon.Icon = System.Drawing.Icon.ExtractAssociatedIcon(System.Windows.Forms.Application.ExecutablePath));
			notifyIcon.Visible = true;
			notifyIcon.MouseClick += OnNotifyIconClick;
			base.StateChanged += Window_StateChanged;
			System.Windows.Forms.MenuItem menuItem = new System.Windows.Forms.MenuItem("退出");
			menuItem.Click += exit_Click;
			System.Windows.Forms.MenuItem menuItem2 = new System.Windows.Forms.MenuItem("帮助");
			menuItem2.Click += help_Click;
			System.Windows.Forms.MenuItem[] menuItems = new System.Windows.Forms.MenuItem[2]
			{
				menuItem2,
				menuItem
			};
			notifyIcon.ContextMenu = new System.Windows.Forms.ContextMenu(menuItems);
		}

		private void exit_Click(object sender, EventArgs e)
		{
			exitApplication();
		}

		private void help_Click(object sender, EventArgs e)
		{
			buttonHelp_Click(null, null);
		}

		private void visibilityChange()
		{
			if (base.Visibility == Visibility.Visible)
			{
				base.Visibility = Visibility.Hidden;
				return;
			}
			base.Visibility = Visibility.Visible;
			Activate();
		}

		private void OnNotifyIconClick(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			if (e.Button == MouseButtons.Left)
			{
				visibilityChange();
			}
		}

		private void Window_StateChanged(object sender, EventArgs e)
		{
			if (base.WindowState == WindowState.Minimized)
			{
				base.Visibility = Visibility.Hidden;
			}
		}

		private string[] distillLines(string fileName)
		{
			if (!File.Exists(fileName))
			{
				return null;
			}
			FileStream fileStream = new FileStream(fileName, FileMode.Open);
			StreamReader streamReader = new StreamReader(fileStream);
			string text = streamReader.ReadToEnd();
			fileStream.Close();
			return text.Split('\n');
		}

		public object GetObject(string Name)
		{
			return GetType().GetField(Name, BindingFlags.IgnoreCase | BindingFlags.Instance | BindingFlags.NonPublic).GetValue(this);
		}

		private void rebindMoveButton()
		{
			((System.Windows.Controls.Button)GetObject("button_10_mm")).Opacity = ((move_distance == 10.0) ? 1.0 : 0.5);
			((System.Windows.Controls.Button)GetObject("button_1_mm")).Opacity = ((move_distance == 1.0) ? 1.0 : 0.5);
			((System.Windows.Controls.Button)GetObject("button_0_1_mm")).Opacity = ((move_distance == 0.1) ? 1.0 : 0.5);
		}

		private void threadNotifyConnectionStatus(int currentConnectionStatus)
		{
			base.Dispatcher.Invoke((Action)delegate
			{
				if (currentConnectionStatus == CONNECTION_LINK)
				{
					imageIndicator.Source = new BitmapImage(new Uri("pack://application:,,,/Images/green.png"));
					threadDisplay("准备就序");
					listViewFileList.ItemsSource = null;
					msgSend("M20 ''");
				}
				else if (currentConnectionStatus == CONNECTION_WARN)
				{
					imageIndicator.Source = new BitmapImage(new Uri("pack://application:,,,/Images/orange.png"));
				}
				else
				{
					imageIndicator.Source = new BitmapImage(new Uri("pack://application:,,,/Images/gray.png"));
					threadDisplay("连接断开");
				}
			}, new object[0]);
		}

		private void enqueueCmd(string cmd)
		{
			lock (cmdQueue)
			{
				cmdQueue.Enqueue(cmd);
			}
		}

		private void msgSend(string cmd)
		{
			if (stop)
			{
				threadDialogShow("设备未连接，请先连接设备！");
			}
			else
			{
				enqueueCmd(cmd);
			}
		}

		private string dequeueCmd()
		{
			string result = null;
			lock (cmdQueue)
			{
				if (cmdQueue.Count > 0)
				{
					return cmdQueue.Dequeue();
				}
				return result;
			}
		}

		private void clearCmd()
		{
			lock (cmdQueue)
			{
				cmdQueue.Clear();
			}
		}

		private void enqueueDat(byte[] dat)
		{
			lock (datQueue)
			{
				datQueue.Enqueue(dat);
			}
		}

		private byte[] dequeueDat()
		{
			byte[] result = null;
			lock (datQueue)
			{
				if (datQueue.Count > 0)
				{
					return datQueue.Dequeue();
				}
				return result;
			}
		}

		private void clearDat()
		{
			lock (datQueue)
			{
				datQueue.Clear();
			}
		}

		private void setAuthButtonValid(bool visible)
		{
			base.Dispatcher.Invoke((Action)delegate
			{
				labelAuth.Visibility = ((!visible) ? Visibility.Hidden : Visibility.Visible);
				textBoxAuth.Visibility = ((!visible) ? Visibility.Hidden : Visibility.Visible);
				buttonSetAuth.Visibility = ((!visible) ? Visibility.Hidden : Visibility.Visible);
			}, new object[0]);
		}

		private void buttonTcpConnect_Click(object sender, RoutedEventArgs e)
		{
			remoteIPAddress = comboBoxIPAddress.Text;
			int num = remoteIPAddress.IndexOf("/");
			if (num > 0)
			{
				if (num + 1 < remoteIPAddress.Length)
				{
					int num2 = remoteIPAddress.IndexOf("/", num + 1);
					if (num2 > 0)
					{
						textBoxDeviceName.Text = remoteIPAddress.Substring(num + 1, num2 - num - 1);
					}
				}
				remoteIPAddress = remoteIPAddress.Substring(0, num);
			}
			if (remoteIPAddress.EndsWith("0.0.0.0"))
			{
				remoteIPAddress = "192.168.4.1";
			}
			if (remoteIPAddress.Length == 0)
			{
				System.Windows.MessageBox.Show("IP 地址输入不能为空", "错误", MessageBoxButton.OK, MessageBoxImage.Hand);
			}
			else
			{
				try
				{
					buttonTcpConnect.IsEnabled = false;
					IPAddress.Parse(remoteIPAddress);
					if (threadConnectIP != null)
					{
						threadConnectIP.Abort();
					}
					threadConnectIP = new Thread(connectRemoteDivce);
					threadConnectIP.Name = "connectIP";
					threadConnectIP.Start();
					if (threadRoutine == null)
					{
						threadRoutine = new Thread(routine);
						threadRoutine.Name = "routine";
						threadRoutine.Start();
					}
				}
				catch
				{
					System.Windows.MessageBox.Show("IP 地址输入不正确", "错误", MessageBoxButton.OK, MessageBoxImage.Hand);
				}
			}
		}

		private string distillCmdName(string cmd)
		{
			string[] array = cmd.Split(' ');
			if (array.Length > 0)
			{
				return array[0];
			}
			return cmd;
		}

		private string RunCmd(string cmdExe, string cmdStr)
		{
			string text = null;
			cmdExe = distillCmdName(cmdExe);
			if (!File.Exists(cmdExe))
			{
				System.Windows.MessageBox.Show("Error!Path '" + cmdExe + "' is not existed!");
				return null;
			}
			try
			{
				using (Process process = new Process())
				{
					process.StartInfo.FileName = "cmd.exe";
					process.StartInfo.UseShellExecute = false;
					process.StartInfo.RedirectStandardInput = true;
					process.StartInfo.RedirectStandardOutput = true;
					process.StartInfo.RedirectStandardError = true;
					process.StartInfo.CreateNoWindow = true;
					process.Start();
					string value = cmdStr + "\r\nexit";
					process.StandardInput.WriteLine(value);
					process.StandardInput.AutoFlush = true;
					process.WaitForExit();
					try
					{
						text = process.StandardOutput.ReadToEnd();
						text += process.StandardError.ReadToEnd();
					}
					catch (Exception)
					{
					}
					process.Close();
					return text;
				}
			}
			catch
			{
				return text;
			}
		}

		private void startSendFile(string fileName)
		{
			clearDat();
			targetSendFileName = Path.GetFileName(fileName);
			msgSend("M28 " + targetSendFileName + "\r\n");
			target_local_file_fi = new FileStream(fileName, FileMode.Open, FileAccess.Read);
		}

		private void compressThread(object o)
		{
			string text = (string)o;
			string text2 = "VC_compress_gcode.exe \"" + text + "\" " + x_mm_per_step + " " + y_mm_per_step + " " + z_mm_per_step + " " + e_mm_per_step + " .\\ " + s_x_max + " " + s_y_max + " " + s_z_max + " " + s_machine_type;
			RunCmd(text2, text2);
			startSendFile(Path.GetFileName(text) + ".tz");
		}

		private void openLocalFile(string fileName)
		{
			if (stop)
			{
				System.Windows.MessageBox.Show("请先连接设备", "错误", MessageBoxButton.OK, MessageBoxImage.Hand);
			}
			else if (checkBoxCompressBeforeSend.IsChecked == true && (Path.GetExtension(fileName).Equals(".gcode") || Path.GetExtension(fileName).Equals(".gco")))
			{
				ParameterizedThreadStart start = compressThread;
				Thread thread = new Thread(start);
				thread.Name = "compress";
				thread.Start(fileName);
				threadDisplay("正在压缩文件:" + Path.GetFileName(fileName));
			}
			else
			{
				startSendFile(fileName);
			}
		}

		private void closeLocaOpenedlFile(bool bSendMsg = true)
		{
			if (target_local_file_fi != null)
			{
				bSendingFileFromLocal = false;
				SDFileReadAlready = 0;
				try
				{
					target_local_file_fi.Close();
					target_local_file_fi = null;
				}
				catch (Exception ex)
				{
					displayToast(ex.ToString());
				}
				target_local_file_fi = null;
				resend_index = -1;
				clearDat();
				if (bSendMsg)
				{
					msgSend("M29");
				}
			}
			if (saved_local_file_fi != null)
			{
				try
				{
					saved_local_file_fi.Close();
					saved_local_file_fi = null;
					clearDat();
				}
				catch (Exception)
				{
				}
				saved_local_file_fi = null;
				if (bSendMsg)
				{
					msgSend("M22");
				}
			}
		}

		private void displayToast(string str)
		{
			base.Dispatcher.Invoke((Action)delegate
			{
				textBlockInfo.Text = str;
			}, new object[0]);
		}

		private void threadTextViewDisplay(string info, string id)
		{
			base.Dispatcher.Invoke((Action)delegate
			{
				((TextBlock)GetObject(id)).Text = info;
			}, new object[0]);
		}

		private void threadDialogShow(string msg, MessageBoxImage image = MessageBoxImage.Hand)
		{
			base.Dispatcher.Invoke((Action)delegate
			{
				System.Windows.MessageBox.Show(msg, (image == MessageBoxImage.Hand) ? "错误" : ((image == MessageBoxImage.Exclamation) ? "警告" : "提示"), MessageBoxButton.OK, image);
			}, new object[0]);
		}

		private void threadDisplay(string str)
		{
			displayToast(str);
		}

		private void showFileList()
		{
			device_file_list_dat.Sort(new myFileCompare());
			Data[] array = new Data[device_file_list_dat.Count];
			int num = 0;
			int num2 = 0;
			string value = (targetSendFileName.Length > 0) ? targetSendFileName : deviceSelectedFileName;
			foreach (Hashtable item in device_file_list_dat)
			{
				Data data = new Data();
				data.name = (string)item["name"];
				data.index = num2 + 1;
				data.kbps = (float)((double)item["size"] / 1000.0);
				if (data.name.Equals(value))
				{
					num = num2;
				}
				array[num2++] = data;
			}
			try
			{
				listViewFileList.ItemsSource = null;
				listViewFileList.ItemsSource = array;
				if (num >= 0)
				{
					listViewFileList.SelectedIndex = num;
				}
			}
			catch (Exception ex)
			{
				threadDialogShow(ex.ToString());
			}
		}

		private void threadNotifyTempeChange(int end, int bed, int targetEnd, int targetBed, int fan)
		{
			base.Dispatcher.Invoke((Action)delegate
			{
				sliderEndTemp.Value = targetEnd;
				sliderBedTemp.Value = targetBed;
				sliderFanRatio.Value = fan;
				textBlockEndTemp.Text = string.Concat(targetEnd);
				textBlockBedTemp.Text = string.Concat(targetBed);
				textBlockFanRatio.Text = string.Concat(fan);
			}, new object[0]);
		}

		private void threadSetProgressBar(int already, int total, int elapsedTime)
		{
			int hour = elapsedTime / 3600;
			int minus = (elapsedTime - hour * 3600) / 60;
			int second = elapsedTime - hour * 3600 - 60 * minus;
			base.Dispatcher.Invoke((Action)delegate
			{
				textBlockFileProgress.Text = "打印进度:" + already * 100 / total + "/100 用时:" + ((total > 0) ? (hour + "时" + minus + "分" + second + "秒") : "--时--分--秒");
			}, new object[0]);
		}

		private void threadShowFileList()
		{
			base.Dispatcher.Invoke((Action)delegate
			{
				showFileList();
			}, new object[0]);
		}

		private void threadGetMachineInfo(string msg)
		{
			x_mm_per_step = getValue(msg, "X:", 0f);
			y_mm_per_step = getValue(msg, "Y:", 0f);
			z_mm_per_step = getValue(msg, "Z:", 0f);
			e_mm_per_step = getValue(msg, "E:", 0f);
			int extrude_num = 1;
			int num = msg.IndexOf("T:");
			if (num > 0)
			{
				s_machine_type = (int)getValue(msg, "T:", 0f);
				num = msg.IndexOf("/", num);
				if (num > 0)
				{
					s_x_max = (int)getValue(msg.Substring(num), "/", 0f);
					num = msg.IndexOf("/", num + 1);
					if (num > 0)
					{
						s_y_max = (int)getValue(msg.Substring(num), "/", 0f);
						num = msg.IndexOf("/", num + 1);
						if (num > 0)
						{
							s_z_max = (int)getValue(msg.Substring(num), "/", 0f);
							num = msg.IndexOf("/", num + 1);
							if (num > 0)
							{
								extrude_num = (int)getValue(msg.Substring(num), "/", 0f);
							}
						}
					}
				}
			}
			num = msg.IndexOf("U:");
			if (num != -1)
			{
				int num2 = msg.IndexOf(msg.Substring(num + 2, 1), num + 3);
				if (num2 != -1)
				{
					try
					{
						string name = msg.Substring(num + 3, num2 - (num + 3));
						ec = Encoding.GetEncoding(name);
					}
					catch (Exception)
					{
						ec = Encoding.GetEncoding("GBK");
					}
				}
			}
			else
			{
				ec = Encoding.GetEncoding("GBK");
			}
			string[] machine_type_array = new string[5]
			{
				"XYZ",
				"三角洲",
				"HBOT",
				"SCARA",
				"DIGGER"
			};
			base.Dispatcher.Invoke((Action)delegate
			{
				textBlockMachineInfo.Text = "机型:" + ((s_machine_type >= 0 && s_machine_type < 5) ? machine_type_array[s_machine_type] : "Unknown") + " 行程:" + s_x_max + "/" + s_y_max + "/" + s_z_max + " 喷头数：" + extrude_num;
			}, new object[0]);
		}

		private void connectRemoteDivce()
		{
			stop = true;
			try
			{
				udpClient = new UdpClient();
				udpClient.Client.SendTimeout = 2000;
				udpClient.Client.ReceiveTimeout = 1800;
				udpClient.Connect(new IPEndPoint(IPAddress.Parse(remoteIPAddress), 3000));
				displayToast("成功连接到设备");
				clearCmd();
				stop = false;
				wifiModuleAuthoFlag = true;
				targetSendFileName = "";
				msgSend("M4001");
				msgSend("M4001");
				msgSend("M99999");
				msgSend("M4002");
				msgSend("M4006");
				wifiMsgSend("U102");
				wifiMsgSend("U103");
			}
			catch (Exception ex)
			{
				stop = true;
				displayToast("无法连接到:" + remoteIPAddress);
				System.Windows.MessageBox.Show(ex.ToString());
			}
			if (!stop)
			{
				bool done = false;
				int index = 0;
				int num = 0;
				int num2 = 0;
				bool flag = false;
				string s;
				string msg;
				int index_t;
				int index_t2;
				while (!stop)
				{
					num2 = 0;
					bool flag2 = false;
					stopCurrentFlag = false;
					byte[] array;
					if ((s = dequeueCmd()) != null)
					{
						if (udpClient != null)
						{
							udpClient.Client.ReceiveTimeout = 1800;
							udpClient.Client.SendTimeout = 2000;
						}
						cmd_appending = true;
						if (!wifiModuleAuthoFlag && !s.StartsWith("U101"))
						{
							continue;
						}
						if (stop)
						{
							base.Dispatcher.Invoke((Action)delegate
							{
								System.Windows.MessageBox.Show("网络未连接!请先连接网络", "错误", MessageBoxButton.OK, MessageBoxImage.Hand);
							}, new object[0]);
						}
						else
						{
							IPEndPoint remoteEP = new IPEndPoint(IPAddress.Any, 0);
							while (udpClient.Available > 0)
							{
								array = udpClient.Receive(ref remoteEP);
							}
							if (s.StartsWith("M28") || s.StartsWith("M30") || s.StartsWith("M6030"))
							{
								byte[] bytes = ec.GetBytes(s);
								udpClient.Send(bytes, bytes.Length);
							}
							else
							{
								if (s.StartsWith("#"))
								{
									flag2 = true;
									s = s.Substring(1);
									if (!debugVerbose)
									{
										threadAppendTextToDbgInfo(s, false);
									}
								}
								byte[] array2 = s.StartsWith("U") ? ec_utf8.GetBytes(s) : ec.GetBytes(s);
								udpClient.Send(array2, array2.Length);
							}
							if (debugVerbose)
							{
								threadAppendTextToDbgInfo(s, false);
							}
							flag = (timeoutFlag = false);
							done = false;
							while (!stopCurrentFlag && !s.StartsWith("G28"))
							{
								try
								{
									if (flag)
									{
										byte[] bytes2 = ec.GetBytes("M4004");
										udpClient.Send(bytes2, bytes2.Length);
										if (debugVerbose)
										{
											threadAppendTextToDbgInfo("M4004", false);
										}
									}
									array = udpClient.Receive(ref remoteEP);
									int num3 = array.Length;
									if (saved_local_file_fi != null && num3 >= 6 && array[num3 - 1] == 131)
									{
										getRemoteDat(array, false);
									}
									else
									{
										msg = ec.GetString(array, 0, num3);
										if (flag)
										{
											if (debugVerbose)
											{
												threadAppendTextToDbgInfo(msg, true);
											}
											if (!msg.StartsWith("ok"))
											{
												threadDisplay("ERROR receive:" + msg);
												done = true;
												goto IL_14e1;
											}
											num2 = 0;
											if ((int)getValue(msg, "C:", -1f) == 1)
											{
												flag = (timeoutFlag = false);
											}
											else
											{
												if (!s.Equals("M20 ''"))
												{
													if (timeoutFlag)
													{
														threadDisplay("准备就序");
													}
													flag = (timeoutFlag = false);
													done = true;
													goto IL_14e1;
												}
												byte[] bytes3 = ec.GetBytes(s);
												udpClient.Send(bytes3, bytes3.Length);
												flag = (timeoutFlag = false);
											}
										}
										else
										{
											flag = (timeoutFlag = false);
											if (debugVerbose)
											{
												threadAppendTextToDbgInfo(msg, true);
											}
											if (msg.StartsWith("Error:IP connected by"))
											{
												clearConnection(false);
												closeLocaOpenedlFile(false);
												threadDialogShow(msg + "设备被其他用户连接，请重连！");
												done = true;
											}
											else if (msg.StartsWith("Error:wifi module not authorized!"))
											{
												threadDialogShow("Wifi模块未授权，请按帮助文档的方法索取授权！");
												wifiModuleAuthoFlag = false;
												done = true;
												setAuthButtonValid(true);
											}
											else if (flag2)
											{
												if (msg.Contains("ok") || msg.Contains("Error"))
												{
													done = true;
												}
												if (!debugVerbose)
												{
													threadAppendTextToDbgInfo(msg, true);
												}
											}
											else if (s == "M4000")
											{
												if (msg.StartsWith("Error"))
												{
													clearConnection(false);
													threadDialogShow(msg);
													done = true;
												}
												if (msg.Contains("B"))
												{
													int num4 = (int)getValue(msg, "E1:", -1f);
													int num5 = (int)getValue(msg, "B:", -1f);
													int targetEnd = (int)getValue(msg, "/", 0f, "E1:");
													int targetBed = (int)getValue(msg, "/", 0f, "B:");
													int fan = (int)getValue(msg, "F:", 0f);
													threadTextViewDisplay("  挤出头:" + num4 + "℃ 热床:" + num5 + "℃", "textTemperation");
													threadNotifyTempeChange(num4, num5, targetEnd, targetBed, fan);
												}
												if (msg.Contains("X"))
												{
													float value = getValue(msg, "X:", 0f);
													float value2 = getValue(msg, "Y:", 0f);
													float value3 = getValue(msg, "Z:", 0f);
													threadTextViewDisplay("X:" + value + " Y:" + value2 + " Z:" + value3, "textCoordination");
												}
												if (target_local_file_fi == null && saved_local_file_fi == null && msg.Contains("D:"))
												{
													int num6 = (int)getValue(msg, "D:", 0f);
													int num7 = (int)getValue(msg, "/", 100f, "D:");
													int elapsedTime = (int)getValue(msg, "T:", 100f);
													if (num7 == 0)
													{
														fileOpendFlag = false;
														num7 = 100;
														num6 = 0;
													}
													else
													{
														fileOpendFlag = true;
													}
													if (fileOpendFlag)
													{
														filePauseFlag = (int)getValue(msg, num6 + "/" + num7 + "/", 100f, "D:");
													}
													else
													{
														filePauseFlag = -1;
													}
													threadSetProgressBar(num6, num7, elapsedTime);
												}
												done = true;
											}
											else if (s == "M20 ''")
											{
												if (msg.StartsWith("Error,"))
												{
													threadDialogShow(msg + "请等待打印/写入完成再扫描");
													done = true;
												}
												else if (msg.StartsWith("Begin file list"))
												{
													num = (index = 0);
													device_file_list_dat = new ArrayList();
												}
												else if (msg.StartsWith("End file list"))
												{
													if (!bLoadFromFromLocal)
													{
														threadShowFileList();
													}
												}
												else if (msg.StartsWith("ok"))
												{
													int num8 = (int)getValue(msg, "L:", -1f);
													if (num8 < 0 || num8 == num)
													{
														done = true;
														if (device_file_list_dat.Count == 0)
														{
															threadDialogShow(bLangEn ? "No SD or empty in SD" : "未插卡或卡为空", MessageBoxImage.Exclamation);
														}
													}
													else
													{
														byte[] bytes4 = ec.GetBytes(s);
														udpClient.Send(bytes4, bytes4.Length);
														num = (index = 0);
														device_file_list_dat = new ArrayList();
													}
												}
												else
												{
													num++;
													string[] array3 = msg.Split(" ".ToCharArray());
													if (array3.Length >= 2 && !msg.StartsWith("->"))
													{
														string text = array3[0];
														for (int i = 1; i < array3.Length - 1; i++)
														{
															text = text + " " + array3[i];
														}
														Hashtable hashtable = new Hashtable();
														try
														{
															hashtable.Add("index", ++index);
															hashtable.Add("name", text);
															hashtable.Add("size", Convert.ToDouble(array3[array3.Length - 1]));
															device_file_list_dat.Add(hashtable);
														}
														catch (Exception)
														{
														}
													}
												}
											}
											else if (s.StartsWith("M6030") || s.StartsWith("M28"))
											{
												if (msg.Contains("Error"))
												{
													closeLocaOpenedlFile();
													done = true;
													if (s.StartsWith("M28"))
													{
														threadDialogShow(msg + (bLangEn ? "Creating file error!" : "文件创建失败"));
													}
													else
													{
														threadDialogShow(msg + (bLangEn ? "Cann't open file" : "无法打开文件"));
													}
												}
												else if (msg.Contains("ok"))
												{
													done = true;
													if (s.StartsWith("M28") && target_local_file_fi != null)
													{
														threadDisplay("正在发送文件:" + targetSendFileName + ",大小:" + target_local_file_fi.Length + "B");
													}
												}
												else if (msg.Contains("Choice"))
												{
													switch ((int)getValue(msg, "Choice:", 0f))
													{
													case 101:
														base.Dispatcher.Invoke((Action)delegate
														{
															switch (System.Windows.MessageBox.Show("是否从断点开始打印？", "信息", MessageBoxButton.YesNoCancel, MessageBoxImage.Asterisk))
															{
															case MessageBoxResult.Yes:
																msgSend(s + " I" + 2);
																done = true;
																break;
															case MessageBoxResult.No:
																msgSend(s + " I" + 1);
																done = true;
																break;
															}
														}, new object[0]);
														break;
													case 102:
														base.Dispatcher.Invoke((Action)delegate
														{
															switch (System.Windows.MessageBox.Show("是否从当前Z位置打印？", "信息", MessageBoxButton.YesNoCancel, MessageBoxImage.Asterisk))
															{
															case MessageBoxResult.Yes:
																msgSend(s + " I" + 3);
																done = true;
																break;
															case MessageBoxResult.No:
																msgSend(s + " I" + 1);
																done = true;
																break;
															}
														}, new object[0]);
														break;
													}
												}
											}
											else if (s.StartsWith("M6032"))
											{
												if (msg.Contains("Error"))
												{
													done = true;
													threadDialogShow("文件无法打印，导出失败!");
												}
												else if (msg.Contains("ok"))
												{
													done = true;
													saved_local_file_length = (uint)getValue(msg, "L:", 0f);
													if (saved_local_file_length != 0)
													{
														try
														{
															saved_local_file_index = 0u;
															saved_local_file_fi = new FileStream(saved_local_file_name, FileMode.Create, FileAccess.Write);
															threadDisplay("正在导出文件:" + Path.GetFileName(saved_local_file_fi.Name) + ",大小:" + saved_local_file_length + "B");
														}
														catch (Exception)
														{
															threadDialogShow("无法创建文件:" + saved_local_file_name);
														}
													}
												}
											}
											else if (s.StartsWith("M4001"))
											{
												if (msg.StartsWith("Error"))
												{
													threadDialogShow(msg);
													clearConnection(false);
												}
												threadGetMachineInfo(msg);
												done = true;
											}
											else if (s.StartsWith("M9005") || s.StartsWith("M9003"))
											{
												if (msg.Contains("ok"))
												{
													threadDialogShow(bLangEn ? "Configuration OK!" : "配置成功！", MessageBoxImage.Asterisk);
												}
												else
												{
													threadDialogShow(bLangEn ? "Configuration fail!" : "配置失败！");
												}
												done = true;
											}
											else if (s.StartsWith("M4003"))
											{
												if (msg.Contains("ok"))
												{
													threadDialogShow(bLangEn ? "Close device OK!" : "关闭设备成功！", MessageBoxImage.Asterisk);
													clearConnection(false);
													closeLocaOpenedlFile(false);
												}
												else
												{
													threadDialogShow(bLangEn ? "Close device fail!" : "关闭设备失败！");
												}
												done = true;
											}
											else if (s.StartsWith("M4002"))
											{
												if (msg.StartsWith("ok "))
												{
													versionNum = msg.Substring(3, msg.Length - 3);
													versionNum = versionNum.Replace("\r", "");
													versionNum = versionNum.Replace("\n", "");
													threadTextViewDisplay(remoteIPAddress + "/" + versionNum + "/" + wifiFirmwareVersion, "textBlockIPAddress");
												}
												done = true;
											}
											else if (s.Equals("M4006"))
											{
												try
												{
													int num9 = msg.IndexOf("'");
													if (num9 > 0)
													{
														int num10 = msg.IndexOf("'", num9 + 1);
														if (num10 > 0)
														{
															deviceSelectedFileName = msg.Substring(num9 + 1, num10 - num9 - 1);
															done = true;
														}
													}
												}
												catch (Exception)
												{
												}
											}
											else if (s.Equals("M99999"))
											{
												int num11 = msg.IndexOf("VER:");
												if (num11 > 0)
												{
													int num12 = msg.IndexOf(" ", num11 + 4);
													if (num12 > 0)
													{
														wifiFirmwareVersion = msg.Substring(num11 + 4, num12 - (num11 + 4));
													}
												}
												done = true;
											}
											else if (s.StartsWith("U102&"))
											{
												index = msg.IndexOf("SSID:");
												if (index > 0)
												{
													index_t = msg.IndexOf("PWD:");
													if (index_t > 0)
													{
														base.Dispatcher.Invoke((Action)delegate
														{
															textBoxLoacalSSid.Text = msg.Substring(index + 5, index_t - (index + 5) - 1);
														}, new object[0]);
														index = msg.IndexOf("\r");
														if (index > 0)
														{
															base.Dispatcher.Invoke((Action)delegate
															{
																textBoxLoacalSSidPassword.Password = msg.Substring(index_t + 4, index - (index_t + 4));
															}, new object[0]);
														}
													}
												}
												done = true;
											}
											else if (s.StartsWith("U103&"))
											{
												index = msg.IndexOf("SSID:");
												if (index > 0)
												{
													index_t2 = msg.IndexOf("PWD:");
													if (index_t2 > 0)
													{
														base.Dispatcher.Invoke((Action)delegate
														{
															textBoxRouterSSid.Text = msg.Substring(index + 5, index_t2 - (index + 5) - 1);
														}, new object[0]);
														index = msg.IndexOf("\r");
														if (index > 0)
														{
															base.Dispatcher.Invoke((Action)delegate
															{
																textBoxRouterSSidPassword.Password = msg.Substring(index_t2 + 4, index - (index_t2 + 4));
															}, new object[0]);
														}
													}
												}
												done = true;
											}
											else if (msg.Contains("ok"))
											{
												if (s.StartsWith("U100 "))
												{
													threadDialogShow("设备名称设置成功，重新扫描可看到新的设备名!", MessageBoxImage.Asterisk);
												}
												else if (s.StartsWith("U101 "))
												{
													threadDialogShow("授权成功!重新连接后能正常工作！", MessageBoxImage.Asterisk);
												}
												done = true;
											}
											else if (msg.Contains("Error"))
											{
												if (s.StartsWith("U100 "))
												{
													threadDialogShow("设备名称设置失败!");
												}
												else if (s.StartsWith("U101 "))
												{
													threadDialogShow("授权失败!");
												}
												done = true;
											}
											else if (msg.Contains("I") && msg.Contains("E"))
											{
												msg.Contains("B");
											}
											if (done)
											{
												goto IL_14e1;
											}
										}
									}
								}
								catch (SocketException)
								{
									if (stopCurrentFlag)
									{
										goto IL_14e1;
									}
									flag = true;
									if (num2 > 2)
									{
										timeoutFlag = true;
										threadDisplay("超时...");
									}
									if (num2 > 6 || s.Equals("M4001"))
									{
										threadDisplay("网络断开");
										clearConnection(false);
										base.Dispatcher.Invoke((Action)delegate
										{
											System.Windows.MessageBox.Show("网络断开", "错误", MessageBoxButton.OK, MessageBoxImage.Hand);
										}, new object[0]);
										goto IL_14e1;
									}
									num2++;
								}
								catch (ThreadAbortException)
								{
								}
								catch (Exception ex7)
								{
									System.Windows.MessageBox.Show(ex7.ToString(), "错误", MessageBoxButton.OK, MessageBoxImage.Hand);
									clearConnection(false);
									goto IL_14e1;
								}
							}
						}
						goto IL_14e1;
					}
					if ((resend_index == -1 || saved_local_file_fi != null) && (array = dequeueDat()) != null)
					{
						if (saved_local_file_fi != null || target_local_file_fi != null)
						{
							udpClient.Client.ReceiveTimeout = 150;
							udpClient.Client.SendTimeout = 150;
							IPEndPoint remoteEP = new IPEndPoint(IPAddress.Any, 0);
							if (udpClient.Available > 0)
							{
								udpClient.Receive(ref remoteEP);
							}
							udpClient.Send(array, array.Length);
							FileStream saved_local_file_fi2 = saved_local_file_fi;
							num2 = 0;
							while (!stopCurrentFlag)
							{
								try
								{
									byte[] array4 = udpClient.Receive(ref remoteEP);
									num2 = 0;
									int num13 = array4.Length;
									if (ec.GetString(array, 0, array.Length).Equals("M3000"))
									{
										if (num13 >= 6 && array4[num13 - 1] == 131)
										{
											BitConverter.ToUInt32(array4, num13 - 6);
											if (getRemoteDat(array4, true))
											{
												goto IL_1779;
											}
										}
										else if (ec.GetString(array4, 0, num13).Contains("Error"))
										{
											threadDialogShow(ec.GetString(array4, 0, num13));
											closeLocaOpenedlFile();
											goto IL_1779;
										}
									}
									else
									{
										msg = ec.GetString(array4, 0, array4.Length);
										if (msg.StartsWith("ok") || stopCurrentFlag)
										{
											goto IL_1779;
										}
										if (msg.Contains("resend"))
										{
											resend_index = (int)getValue(msg, "resend ", -1f);
											goto IL_1779;
										}
										if (msg.Contains("Error"))
										{
											System.Windows.MessageBox.Show("传输错误！" + msg, "错误", MessageBoxButton.OK, MessageBoxImage.Hand);
											clearConnection(false);
											closeLocaOpenedlFile();
											goto IL_1779;
										}
									}
								}
								catch (SocketException)
								{
									if (stop)
									{
										goto IL_1779;
									}
									try
									{
										udpClient.Send(array, array.Length);
									}
									catch (Exception)
									{
									}
									num2++;
									if (num2 > 50)
									{
										System.Windows.MessageBox.Show("传输超时！", "错误", MessageBoxButton.OK, MessageBoxImage.Hand);
										clearConnection(false);
										closeLocaOpenedlFile();
										goto IL_1779;
									}
								}
								catch (Exception ex10)
								{
									System.Windows.MessageBox.Show(ex10.ToString(), "错误", MessageBoxButton.OK, MessageBoxImage.Hand);
									clearConnection(false);
									closeLocaOpenedlFile();
									goto IL_1779;
								}
							}
						}
					}
					else
					{
						Thread.Sleep(10);
					}
					continue;
					IL_14e1:
					cmd_appending = false;
					IL_1779:;
				}
			}
			threadConnectIP = null;
		}

		private bool getRemoteDat(byte[] rcvDat, bool need_resend)
		{
			bool result = false;
			bool flag = false;
			int num = rcvDat.Length;
			uint num2 = uint.MaxValue;
			if (num >= 6 && rcvDat[num - 1] == 131)
			{
				num2 = BitConverter.ToUInt32(rcvDat, num - 6);
				if (num2 > saved_local_file_index)
				{
					flag = true;
				}
				else
				{
					byte b = 0;
					for (int i = 0; i < num - 2; i++)
					{
						b = (byte)(b ^ rcvDat[i]);
					}
					if (b != rcvDat[num - 2])
					{
						flag = true;
					}
				}
			}
			if (need_resend && flag)
			{
				byte[] bytes = ec.GetBytes("M3001 I" + saved_local_file_index);
				udpClient.Send(bytes, bytes.Length);
				result = true;
			}
			else if (saved_local_file_index == num2)
			{
				saved_local_file_fi.Write(rcvDat, 0, num - 6);
				saved_local_file_index += (uint)(num - 6);
				if (saved_local_file_index >= saved_local_file_length)
				{
					threadDisplay("成功导出文件:" + Path.GetFileName(saved_local_file_fi.Name));
					closeLocaOpenedlFile();
				}
				result = true;
			}
			return result;
		}

		private float getValue(string str, string prefix, float default_val)
		{
			return getValue(str, prefix, default_val, null);
		}

		private float getValue(string str, string prefix, float default_val, string ahead)
		{
			try
			{
				int num = 0;
				if (ahead != null)
				{
					num = str.IndexOf(ahead);
					if (num != -1)
					{
						num += ahead.Length;
					}
				}
				int num2 = str.IndexOf(prefix, num);
				if (num2 != -1)
				{
					num2 += prefix.Length;
					int num3 = 0;
					char[] array = str.ToCharArray();
					for (int i = num2; i < str.Length; i++)
					{
						char c = array[i];
						if ((c < '0' || c > '9') && c != '.' && c != '-')
						{
							break;
						}
						num3++;
					}
					if (num3 > 0)
					{
						return (float)Convert.ToDouble(str.Substring(num2, num3));
					}
					return default_val;
				}
				return default_val;
			}
			catch (Exception ex)
			{
				threadDisplay(ex.ToString());
				return default_val;
			}
		}

		private void clearConnection(bool abortThread = true)
		{
			if (!stop)
			{
				stop = true;
				if (udpClient != null)
				{
					udpClient.Close();
					udpClient = null;
				}
				if (abortThread && threadConnectIP != null)
				{
					threadConnectIP.Abort();
					threadConnectIP = null;
				}
			}
			fileOpendFlag = false;
			filePauseFlag = -1;
			threadDisplay("已经从设备断开");
		}

		private void buttonTcpDisconnect_Click(object sender, RoutedEventArgs e)
		{
			buttonTcpDisconnect.IsEnabled = false;
			closeLocaOpenedlFile(false);
			clearConnection();
		}

		private void threadSetViewValid(string id, bool enable)
		{
			base.Dispatcher.Invoke((Action)delegate
			{
				((System.Windows.Controls.Button)GetObject(id)).IsEnabled = enable;
			}, new object[0]);
		}

		private void routine()
		{
			long num = 0L;
			last_stop = false;
			long num2;
			long num3 = num2 = getMs();
			int num4 = -2;
			while (true)
			{
				try
				{
					while (true)
					{
						if (stop)
						{
							currentConnectionStatus = CONNECTION_UNLINK;
						}
						else if (timeoutFlag)
						{
							currentConnectionStatus = CONNECTION_WARN;
						}
						else
						{
							currentConnectionStatus = CONNECTION_LINK;
						}
						if (lastConnectionStatus != currentConnectionStatus)
						{
							threadNotifyConnectionStatus(currentConnectionStatus);
							lastConnectionStatus = currentConnectionStatus;
						}
						if (last_stop != stop)
						{
							if (stop)
							{
								threadSetViewValid("buttonTcpConnect", true);
								threadSetViewValid("buttonTcpDisconnect", false);
								threadSetViewValid("buttonSendFile", false);
								threadSetViewValid("buttonRefresh", false);
								threadSetViewValid("buttonPrint", false);
								threadSetViewValid("buttonDelete", false);
								threadSetViewValid("buttonSetWifiHot", false);
								threadSetViewValid("buttonSetRouterWifi", false);
								threadSetViewValid("buttonDeviceNameSet", false);
								threadSetViewValid("buttonSetAuth", false);
								threadSetViewValid("buttonCloseDevice", false);
								threadSetViewValid("buttonSendCode", false);
								threadSetViewValid("buttonClearDebugInfo", false);
								threadSetViewValid("buttonExport", false);
								handButtonEnable(false);
								last_stop = true;
							}
							else
							{
								threadSetViewValid("buttonTcpConnect", false);
								threadSetViewValid("buttonTcpDisconnect", true);
								threadSetViewValid("buttonSendFile", true);
								threadSetViewValid("buttonRefresh", true);
								threadSetViewValid("buttonPrint", true);
								threadSetViewValid("buttonDelete", true);
								threadSetViewValid("buttonSetWifiHot", true);
								threadSetViewValid("buttonSetRouterWifi", true);
								threadSetViewValid("buttonDeviceNameSet", true);
								threadSetViewValid("buttonSetAuth", true);
								threadSetViewValid("buttonCloseDevice", true);
								threadSetViewValid("buttonSendCode", true);
								threadSetViewValid("buttonClearDebugInfo", true);
								threadSetViewValid("buttonExport", true);
								handButtonEnable(true);
								last_stop = false;
							}
						}
						if (last_fileOpenFlag != temp_fileOpenFlag)
						{
							if (temp_fileOpenFlag)
							{
								threadSetViewValid("buttonSendFile", false);
								threadSetViewValid("buttonRefresh", false);
								threadSetViewValid("buttonPrint", false);
								threadSetViewValid("buttonExport", false);
								if (!stop)
								{
									threadSetViewValid("buttonStop", true);
								}
								threadSetViewValid("buttonDelete", false);
								last_fileOpenFlag = true;
							}
							else
							{
								threadSetViewValid("buttonSendFile", true);
								threadSetViewValid("buttonRefresh", true);
								threadSetViewValid("buttonPrint", true);
								threadSetViewValid("buttonExport", true);
								threadSetViewValid("buttonStop", false);
								threadSetViewValid("buttonPause", false);
								threadSetViewValid("buttonResume", false);
								threadSetViewValid("buttonDelete", true);
								last_fileOpenFlag = false;
							}
						}
						if (num4 != filePauseFlag)
						{
							num4 = filePauseFlag;
							if (filePauseFlag < 0 || !temp_fileOpenFlag || stop)
							{
								threadSetViewValid("buttonPause", false);
								threadSetViewValid("buttonResume", false);
							}
							else if (filePauseFlag > 0)
							{
								threadSetViewValid("buttonPause", false);
								threadSetViewValid("buttonResume", true);
							}
							else
							{
								threadSetViewValid("buttonPause", true);
								threadSetViewValid("buttonResume", false);
							}
						}
						if (target_local_file_fi != null || saved_local_file_fi != null)
						{
							temp_fileOpenFlag = true;
							filePauseFlag = -1;
							num3 = getMs();
							if (target_local_file_fi != null && resend_index != -1)
							{
								clearDat();
								target_local_file_fi.Seek(resend_index, SeekOrigin.Begin);
								resend_index = -1;
							}
							while (datQueue.Count < 15)
							{
								if (target_local_file_fi != null)
								{
									int num5 = 1280;
									byte[] array = new byte[num5 + 6];
									int num6 = 0;
									try
									{
										if (target_local_file_fi.Position >= target_local_file_fi.Length)
										{
											if (datQueue.Count == 0)
											{
												string name = target_local_file_fi.Name;
												threadDisplay("成功发送文件:" + Path.GetFileName(target_local_file_fi.Name));
												closeLocaOpenedlFile();
												if (Path.GetExtension(name).Equals(".tz"))
												{
													File.Delete(name);
												}
												msgSend("M29");
												base.Dispatcher.Invoke((Action)delegate
												{
													listViewFileList.ItemsSource = null;
												}, new object[0]);
												msgSend("M20 ''");
											}
											break;
										}
										int value = (int)target_local_file_fi.Position;
										if ((num6 = target_local_file_fi.Read(array, 0, num5)) <= 0)
										{
											closeLocaOpenedlFile();
											break;
										}
										byte b = 0;
										byte[] bytes = BitConverter.GetBytes(value);
										array[num6] = bytes[0];
										array[num6 + 1] = bytes[1];
										array[num6 + 2] = bytes[2];
										array[num6 + 3] = bytes[3];
										for (int i = 0; i < num6 + 4; i++)
										{
											b = (byte)(b ^ array[i]);
										}
										array[num6 + 4] = b;
										array[num6 + 5] = 131;
										if (num6 == num5)
										{
											enqueueDat(array);
										}
										else
										{
											byte[] array2 = new byte[num6 + 6];
											Array.Copy(array, 0, array2, 0, num6 + 6);
											enqueueDat(array2);
										}
									}
									catch (Exception ex)
									{
										threadDialogShow(ex.ToString());
										closeLocaOpenedlFile();
									}
								}
								else if (saved_local_file_fi != null)
								{
									enqueueDat(ec.GetBytes("M3000"));
								}
							}
							if ((int)(num3 - num2) > 2500)
							{
								if (target_local_file_fi != null)
								{
									threadTextViewDisplay("进度:" + 100 * target_local_file_fi.Position / target_local_file_fi.Length + "/100 速度:" + (target_local_file_fi.Position - num) / (num3 - num2) + "KBps", "textBlockFileProgress");
									num = target_local_file_fi.Position;
								}
								else if (saved_local_file_fi != null && saved_local_file_length != 0)
								{
									threadTextViewDisplay("进度:" + 100 * saved_local_file_fi.Position / (long)saved_local_file_length + "/100 速度:" + (saved_local_file_fi.Position - num) / (num3 - num2) + "KBps", "textBlockFileProgress");
									num = saved_local_file_fi.Position;
								}
								num2 = num3;
								if (!stop && !cmd_appending)
								{
									msgSend("M4000");
								}
							}
							Thread.Sleep(30);
						}
						else
						{
							num3 = getMs();
							num = 0L;
							if (num3 - num2 > 2200)
							{
								num2 = num3;
								if (!stop && !cmd_appending)
								{
									msgSend("M4000");
								}
							}
							Thread.Sleep(300);
							temp_fileOpenFlag = fileOpendFlag;
						}
					}
				}
				catch (Exception ex2)
				{
					threadDialogShow(ex2.ToString());
					threadDisplay("SenderLoopThread");
				}
			}
		}

		private bool checkFilePrintStatus()
		{
			if (fileOpendFlag)
			{
				System.Windows.MessageBox.Show("文件正在打印，请先停止打印再操作!", "警告", MessageBoxButton.OK, MessageBoxImage.Exclamation);
				return false;
			}
			return true;
		}

		private void button_X_plus_Click(object sender, RoutedEventArgs e)
		{
			if (checkFilePrintStatus())
			{
				msgSend("G0 X" + move_distance + " F1200 I0");
			}
		}

		private void button_X_minus_Click(object sender, RoutedEventArgs e)
		{
			if (checkFilePrintStatus())
			{
				msgSend("G0 X-" + move_distance + " F1200 I0");
			}
		}

		private void button_Y_plus_Click(object sender, RoutedEventArgs e)
		{
			if (checkFilePrintStatus())
			{
				msgSend("G0 Y" + move_distance + " F1200 I0");
			}
		}

		private void button_Y_minus_Click(object sender, RoutedEventArgs e)
		{
			if (checkFilePrintStatus())
			{
				msgSend("G0 Y-" + move_distance + " F1200 I0");
			}
		}

		private void button_Z_plus_Click(object sender, RoutedEventArgs e)
		{
			if (checkFilePrintStatus())
			{
				msgSend("G0 Z" + move_distance + " F600 I0");
			}
		}

		private void button_Z_minus_Click(object sender, RoutedEventArgs e)
		{
			if (checkFilePrintStatus())
			{
				msgSend("G0 Z-" + move_distance + " F600 I0");
			}
		}

		private void button_E_plus_Click(object sender, RoutedEventArgs e)
		{
			if (checkFilePrintStatus())
			{
				msgSend("G0 E+" + move_distance + " F120 I0");
			}
		}

		private void button_E_minus_Click(object sender, RoutedEventArgs e)
		{
			if (checkFilePrintStatus())
			{
				msgSend("G0 E-" + move_distance + " F120 I0");
			}
		}

		private void button_home_Click(object sender, RoutedEventArgs e)
		{
			if (checkFilePrintStatus())
			{
				msgSend("G28");
			}
		}

		private void button_10_mm_Click(object sender, RoutedEventArgs e)
		{
			move_distance = 10.0;
			rebindMoveButton();
		}

		private void button_1_mm_Click(object sender, RoutedEventArgs e)
		{
			move_distance = 1.0;
			rebindMoveButton();
		}

		private void button_0_1_mm_Click(object sender, RoutedEventArgs e)
		{
			move_distance = 0.1;
			rebindMoveButton();
		}

		private void buttonRefresh_Click(object sender, RoutedEventArgs e)
		{
			listViewFileList.ItemsSource = null;
			msgSend("M20 ''");
		}

		private void buttonPrint_Click(object sender, RoutedEventArgs e)
		{
			System.Windows.Controls.ListView listView = listViewFileList;
			if (listView.SelectedItems != null && listView.SelectedItems.Count > 0 && listView.SelectedItems[0] != null)
			{
				Data data = (Data)listView.SelectedItems[0];
				msgSend("M6030 ':" + data.name + "'");
			}
			else
			{
				System.Windows.MessageBox.Show("没有文件被选中", "警告", MessageBoxButton.OK, MessageBoxImage.Exclamation);
			}
		}

		private void buttonStop_Click(object sender, RoutedEventArgs e)
		{
			switch (System.Windows.MessageBox.Show("是否保存当前断点？", "信息", MessageBoxButton.YesNoCancel, MessageBoxImage.Asterisk))
			{
			case MessageBoxResult.Yes:
				closeLocaOpenedlFile();
				msgSend("M33 I4");
				msgSend("M29");
				break;
			case MessageBoxResult.No:
				closeLocaOpenedlFile();
				msgSend("M33 I5");
				msgSend("M29");
				break;
			}
		}

		private void buttonResume_Click(object sender, RoutedEventArgs e)
		{
			msgSend("M24");
		}

		private void buttonPause_Click(object sender, RoutedEventArgs e)
		{
			msgSend("M25");
		}

		private void buttonDelete_Click(object sender, RoutedEventArgs e)
		{
			System.Windows.Controls.ListView listView = listViewFileList;
			if (listView.SelectedItems.Count > 0 && listView.SelectedItems[0] != null)
			{
				Data data = (Data)listView.SelectedItems[0];
				msgSend("M30 " + data.name);
				listViewFileList.ItemsSource = null;
				msgSend("M20 ''");
			}
			else
			{
				System.Windows.MessageBox.Show("没有文件被选中", "警告", MessageBoxButton.OK, MessageBoxImage.Exclamation);
			}
		}

		private void buttonCloseDevice_Click(object sender, RoutedEventArgs e)
		{
			if (System.Windows.MessageBox.Show("关闭设备会造成设备断电或者重启，确认继续？", "警告", MessageBoxButton.OKCancel, MessageBoxImage.Exclamation) == MessageBoxResult.OK)
			{
				stopAll();
				msgSend("M4003");
			}
		}

		private string getLoccalHotSetString()
		{
			GetObject("textBoxLoacalSSid");
			if (textBoxLoacalSSidPassword.Password.Length == 0)
			{
				if (System.Windows.MessageBox.Show("是否确认密码设置为空？ ", "警告", MessageBoxButton.OKCancel, MessageBoxImage.Exclamation) != MessageBoxResult.OK)
				{
					return null;
				}
			}
			else if (textBoxLoacalSSidPassword.Password.Length < 8)
			{
				System.Windows.MessageBox.Show("密码长度不得小于8个字节", "错误", MessageBoxButton.OK, MessageBoxImage.Hand);
				return null;
			}
			if (textBoxLoacalSSid.Text.Length < 6)
			{
				System.Windows.MessageBox.Show("热点不得小于6个字节", "错误", MessageBoxButton.OK, MessageBoxImage.Hand);
				return null;
			}
			return "M9005\t'\"" + textBoxLoacalSSid.Text + "\",\"" + textBoxLoacalSSidPassword.Password + "\"'";
		}

		private void buttonSetWifiHot_Click(object sender, RoutedEventArgs e)
		{
			string loccalHotSetString = getLoccalHotSetString();
			if (loccalHotSetString != null)
			{
				msgSend(loccalHotSetString);
			}
		}

		private void buttonGenWifiHotConfig_Click(object sender, RoutedEventArgs e)
		{
			string loccalHotSetString = getLoccalHotSetString();
			if (loccalHotSetString != null)
			{
				FileStream fileStream = new FileStream("Wifi热点配置.txt", FileMode.Create);
				StreamWriter streamWriter = new StreamWriter(fileStream, ec_utf8);
				streamWriter.Write(loccalHotSetString);
				streamWriter.Close();
				fileStream.Close();
				Process.Start("Explorer", "/select,.\\Wifi热点配置.txt");
			}
		}

		private string getRouterSetString()
		{
			if (textBoxRouterSSid.Text.Length < 1)
			{
				System.Windows.MessageBox.Show("热点不能为空", "错误", MessageBoxButton.OK, MessageBoxImage.Hand);
				return null;
			}
			return "M9003\t'\"" + textBoxRouterSSid.Text + "\",\"" + textBoxRouterSSidPassword.Password + "\"'";
		}

		private void buttonSetRouterWifi_Click(object sender, RoutedEventArgs e)
		{
			string routerSetString = getRouterSetString();
			if (routerSetString != null && System.Windows.MessageBox.Show("设置错误将可能导致打印机从路由断开，是否继续设置？ ", "警告", MessageBoxButton.OKCancel, MessageBoxImage.Exclamation) == MessageBoxResult.OK)
			{
				msgSend(routerSetString);
			}
		}

		private void buttonGenRouterWifiConfig_Click(object sender, RoutedEventArgs e)
		{
			string routerSetString = getRouterSetString();
			if (routerSetString != null)
			{
				FileStream fileStream = new FileStream("路由热点配置.txt", FileMode.Create);
				StreamWriter streamWriter = new StreamWriter(fileStream, ec_utf8);
				streamWriter.Write(routerSetString);
				streamWriter.Close();
				fileStream.Close();
				Process.Start("Explorer", "/select,.\\路由热点配置.txt");
			}
		}

		private void buttonSendCode_Click(object sender, RoutedEventArgs e)
		{
			string text = comboBoxDebugCode.Text;
			if (text.Length > 0)
			{
				bool flag = false;
				if (text.StartsWith("#"))
				{
					flag = true;
					text = text.Substring(1);
				}
				int num = text.IndexOf(';');
				if (num > 0)
				{
					text = text.Substring(0, num);
				}
				if (flag)
				{
					wifiMsgSend(text);
				}
				else
				{
					msgSend("#" + text);
				}
			}
		}

		private void threadAppendTextToDbgInfo(string str, bool input)
		{
			base.Dispatcher.Invoke((Action)delegate
			{
				System.Windows.Controls.TextBox textBox = GetObject("textBoxDbgInfo") as System.Windows.Controls.TextBox;
				if (textBox.Text.Length < 160000)
				{
					textBox.AppendText((input ? "<-" : "->") + dbgInfoIndex++ + ": " + str + (str.EndsWith("\n") ? "" : "\n"));
				}
				else
				{
					dbgInfoIndex = 1;
					textBox.Text = (input ? "<-" : "->") + dbgInfoIndex + ": " + str;
				}
				textBox.ScrollToEnd();
			}, new object[0]);
		}

		private void Window_Closing(object sender, CancelEventArgs e)
		{
			visibilityChange();
			e.Cancel = true;
		}

		private void exitApplication()
		{
			notifyIcon.Visible = false;
			clearConnection();
			if (threadRoutine != null)
			{
				threadRoutine.Abort();
				threadRoutine = null;
			}
			Environment.Exit(Environment.ExitCode);
			Close();
		}

		private void buttonClearDebugInfo_Click(object sender, RoutedEventArgs e)
		{
			dbgInfoIndex = 1;
			System.Windows.Controls.TextBox textBox = GetObject("textBoxDbgInfo") as System.Windows.Controls.TextBox;
			textBox.Clear();
		}

		private void checkBoxVerbose_Checked(object sender, RoutedEventArgs e)
		{
			debugVerbose = true;
		}

		private void checkBoxVerbose_Unchecked(object sender, RoutedEventArgs e)
		{
			debugVerbose = false;
		}

		public static string GetBroadcast(string ipAddress, string subnetMask)
		{
			byte[] addressBytes = IPAddress.Parse(ipAddress).GetAddressBytes();
			byte[] addressBytes2 = IPAddress.Parse(subnetMask).GetAddressBytes();
			for (int i = 0; i < addressBytes.Length; i++)
			{
				addressBytes[i] = (byte)(~addressBytes2[i] | addressBytes[i]);
			}
			return new IPAddress(addressBytes).ToString();
		}

		private long getMs()
		{
			return DateTime.Now.Ticks / 10000;
		}

		private void scanIP(object o)
		{
			string text = o.ToString();
			int num = text.IndexOf("/");
			if (num <= 0)
			{
				System.Windows.MessageBox.Show("请选择本机IP/掩码", "错误", MessageBoxButton.OK, MessageBoxImage.Hand);
				return;
			}
			UdpClient udpClient = new UdpClient(new IPEndPoint(IPAddress.Any, 0));
			udpClient.Client.ReceiveTimeout = 400;
			string broadcast = GetBroadcast(text.Substring(0, num), text.Substring(num + 1));
			IPEndPoint remoteEP = new IPEndPoint(IPAddress.Parse(broadcast), 3000);
			byte[] bytes = ec_utf8.GetBytes("M99999");
			udpClient.Send(bytes, bytes.Length, remoteEP);
			long ms = getMs();
			Queue<string> ipQueue = new Queue<string>();
			Queue<string> ipQueueAddr = new Queue<string>();
			threadDisplay("正在扫描设备......");
			int num2 = 0;
			do
			{
				try
				{
					byte[] bytes2 = udpClient.Receive(ref remoteEP);
					string[] array = ec_utf8.GetString(bytes2).Split('\n');
					if (array != null)
					{
						string[] array2 = array;
						foreach (string text2 in array2)
						{
							if (text2.Length > 0)
							{
								ipQueue.Enqueue(text2);
								ipQueueAddr.Enqueue(remoteEP.Address.ToString());
								num2++;
							}
						}
					}
				}
				catch (Exception)
				{
					break;
				}
				threadDisplay("已经扫描到" + num2 + "个设备...");
			}
			while (getMs() - ms <= 2200);
			base.Dispatcher.Invoke((Action)delegate
			{
				comboBoxIPAddress.Items.Clear();
				comboBoxIPAddress.Text = "";
				foreach (string item in ipQueue)
				{
					string str = "";
					int num3 = item.IndexOf("IP:");
					int num4 = 0;
					str += ipQueueAddr.Dequeue();
					num3 = item.IndexOf("NAME:");
					if (num3 >= 0)
					{
						num4 = item.IndexOf("\r", num3 + 5);
						if (num4 > 0)
						{
							str = str + "/" + item.Substring(num3 + 5, num4 - (num3 + 5));
						}
					}
					num3 = item.IndexOf("ID:");
					if (num3 >= 0)
					{
						num4 = item.IndexOf(" ", num3 + 3);
						if (num4 > 0)
						{
							str = str + "/" + item.Substring(num3 + 3, num4 - (num3 + 3));
						}
					}
					if (str.Length == 0)
					{
						str = item;
					}
					comboBoxIPAddress.Text = str;
					comboBoxIPAddress.Items.Add(str);
				}
				if (ipQueue.Count == 1)
				{
					buttonTcpConnect_Click(null, null);
				}
			}, new object[0]);
			threadDisplay("成功扫描到" + num2 + "个设备");
			udpClient.Close();
			threadScan = null;
			if (num2 == 0)
			{
				threadDialogShow("扫描不到设备，请检查设备是否连入网络！");
			}
		}

		private void buttonScanIP_Click(object sender, RoutedEventArgs e)
		{
			bool flag = false;
			if (!stop)
			{
				if (System.Windows.MessageBox.Show("设备正在连接，是否断开当前连接进行扫描?", "警告", MessageBoxButton.OKCancel, MessageBoxImage.Exclamation) == MessageBoxResult.OK)
				{
					buttonTcpDisconnect_Click(null, null);
					flag = true;
				}
			}
			else
			{
				flag = true;
			}
			if (flag)
			{
				comboBoxIPAddress.Items.Clear();
				comboBoxIPAddress.Text = "";
				if (threadScan != null)
				{
					threadScan.Abort();
				}
				ParameterizedThreadStart start = scanIP;
				threadScan = new Thread(start);
				threadScan.Name = "connectIP";
				threadScan.Start(comboBoxLocalIP.Text);
			}
		}

		private void wifiMsgSend(string s)
		{
			byte b = 0;
			byte[] bytes = ec_utf8.GetBytes(s);
			byte[] array = bytes;
			foreach (byte b2 in array)
			{
				b = (byte)(b ^ b2);
			}
			msgSend(s + "&" + b + "&");
		}

		private void buttonDeviceNameSet_Click(object sender, RoutedEventArgs e)
		{
			if (textBoxDeviceName.Text.Length == 0)
			{
				System.Windows.MessageBox.Show("设备名称不能为空", "错误", MessageBoxButton.OK, MessageBoxImage.Hand);
			}
			else
			{
				wifiMsgSend("U100 '" + textBoxDeviceName.Text + "'");
			}
		}

		private void buttonSetAuth_Click(object sender, RoutedEventArgs e)
		{
			if (textBoxAuth.Text.Length == 0)
			{
				System.Windows.MessageBox.Show("授权码不能为空", "错误", MessageBoxButton.OK, MessageBoxImage.Hand);
			}
			else
			{
				wifiMsgSend("U101 '" + textBoxAuth.Text + "'");
			}
		}

		private void listViewFileList_Drop(object sender, System.Windows.DragEventArgs e)
		{
			string fileName = ((Array)e.Data.GetData(System.Windows.DataFormats.FileDrop)).GetValue(0).ToString();
			openLocalFile(fileName);
		}

		private void Window_Loaded(object sender, RoutedEventArgs e)
		{
		}

		private void buttonSendFile_Click(object sender, RoutedEventArgs e)
		{
			if (stop)
			{
				System.Windows.MessageBox.Show("请先连接设备", "错误", MessageBoxButton.OK, MessageBoxImage.Hand);
				return;
			}
			Microsoft.Win32.OpenFileDialog openFileDialog = new Microsoft.Win32.OpenFileDialog();
			openFileDialog.Filter = "All files (*.*)|*.*";
			if (openFileDialog.ShowDialog() == true)
			{
				openLocalFile(openFileDialog.FileName);
			}
		}

		private void stopAll()
		{
			closeLocaOpenedlFile();
			clearCmd();
			clearDat();
			stopCurrentFlag = true;
		}

		private void buttonEmergencyStop_Click(object sender, RoutedEventArgs e)
		{
			if (System.Windows.MessageBox.Show("紧急停止可能让文件打印或发送停止，确认继续？ ", "警告", MessageBoxButton.OKCancel, MessageBoxImage.Exclamation) == MessageBoxResult.OK)
			{
				stopAll();
				msgSend("M112");
			}
		}

		private void sliderEndTemp_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			textBlockEndTemp.Text = ((int)sliderEndTemp.Value).ToString();
			msgSend("M104 S" + (int)sliderEndTemp.Value);
		}

		private void sliderBedTemp_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			textBlockBedTemp.Text = ((int)sliderBedTemp.Value).ToString();
			msgSend("M140 S" + (int)sliderBedTemp.Value);
		}

		private void sliderFanRatio_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
		{
			textBlockFanRatio.Text = ((int)sliderFanRatio.Value).ToString();
			msgSend("M106 S" + (int)sliderFanRatio.Value);
		}

		private void buttonHelp_Click(object sender, RoutedEventArgs e)
		{
			Process.Start(System.Windows.Forms.Application.StartupPath + "\\ChiTu HB软件说明.pdf");
		}

		private void buttonExport_Click(object sender, RoutedEventArgs e)
		{
			System.Windows.Controls.ListView listView = listViewFileList;
			if (listView.SelectedItems != null && listView.SelectedItems.Count > 0 && listView.SelectedItems[0] != null)
			{
				Data data = (Data)listView.SelectedItems[0];
				Microsoft.Win32.SaveFileDialog saveFileDialog = new Microsoft.Win32.SaveFileDialog();
				saveFileDialog.Filter = "All files (*.*)|*.*";
				saveFileDialog.FileName = data.name;
				if (saveFileDialog.ShowDialog() == true)
				{
					saved_local_file_name = saveFileDialog.FileName;
					msgSend("M6032 '" + data.name + "'");
				}
			}
			else
			{
				System.Windows.MessageBox.Show("没有文件被选中", "错误", MessageBoxButton.OK, MessageBoxImage.Hand);
			}
		}

		private void sliderBedTemp_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
		{
			textBlockBedTemp.Text = ((int)sliderBedTemp.Value).ToString();
		}

		private void sliderEndTemp_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
		{
			textBlockEndTemp.Text = ((int)sliderEndTemp.Value).ToString();
		}

		private void sliderFanRatio_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
		{
			textBlockFanRatio.Text = ((int)sliderFanRatio.Value).ToString();
		}

		private void handButtonEnable(bool enable)
		{
			base.Dispatcher.Invoke((Action)delegate
			{
				button_X_minus.IsEnabled = enable;
				button_X_plus.IsEnabled = enable;
				button_Y_minus.IsEnabled = enable;
				button_Y_plus.IsEnabled = enable;
				button_Z_minus.IsEnabled = enable;
				button_Z_plus.IsEnabled = enable;
				button_E_minus.IsEnabled = enable;
				button_E_plus.IsEnabled = enable;
				button_home.IsEnabled = enable;
				sliderBedTemp.IsEnabled = enable;
				sliderEndTemp.IsEnabled = enable;
				sliderFanRatio.IsEnabled = enable;
				buttonEmergencyStop.IsEnabled = enable;
			}, new object[0]);
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		public void InitializeComponent()
		{
			if (!_contentLoaded)
			{
				_contentLoaded = true;
				Uri resourceLocator = new Uri("/wifi_UI;component/mainwindow.xaml", UriKind.Relative);
				System.Windows.Application.LoadComponent(this, resourceLocator);
			}
		}

		[DebuggerNonUserCode]
		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		internal Delegate _CreateDelegate(Type delegateType, string handler)
		{
			return Delegate.CreateDelegate(delegateType, this, handler);
		}

		[GeneratedCode("PresentationBuildTasks", "4.0.0.0")]
		[DebuggerNonUserCode]
		[EditorBrowsable(EditorBrowsableState.Never)]
		void IComponentConnector.Connect(int connectionId, object target)
		{
			switch (connectionId)
			{
			case 1:
				((MainWindow)target).Closing += Window_Closing;
				((MainWindow)target).Loaded += Window_Loaded;
				break;
			case 2:
				textBlockMachineInfo = (TextBlock)target;
				break;
			case 3:
				textCoordination = (TextBlock)target;
				break;
			case 4:
				textTemperation = (TextBlock)target;
				break;
			case 5:
				textBlockInfo = (TextBlock)target;
				break;
			case 6:
				textBlockIPAddress = (TextBlock)target;
				break;
			case 7:
				imageIndicator = (System.Windows.Controls.Image)target;
				break;
			case 8:
				groupBox1 = (System.Windows.Controls.GroupBox)target;
				break;
			case 9:
				textBoxDbgInfo = (System.Windows.Controls.TextBox)target;
				break;
			case 10:
				buttonSendCode = (ImageButton)target;
				break;
			case 11:
				checkBoxVerbose = (System.Windows.Controls.CheckBox)target;
				checkBoxVerbose.Checked += checkBoxVerbose_Checked;
				checkBoxVerbose.Unchecked += checkBoxVerbose_Unchecked;
				break;
			case 12:
				buttonClearDebugInfo = (ImageButton)target;
				break;
			case 13:
				comboBoxDebugCode = (System.Windows.Controls.ComboBox)target;
				break;
			case 14:
				groupBox3 = (System.Windows.Controls.GroupBox)target;
				break;
			case 15:
				buttonTcpConnect = (ImageButton)target;
				break;
			case 16:
				buttonTcpDisconnect = (ImageButton)target;
				break;
			case 17:
				label10 = (System.Windows.Controls.Label)target;
				break;
			case 18:
				buttonScanIP = (ImageButton)target;
				break;
			case 19:
				comboBoxIPAddress = (System.Windows.Controls.ComboBox)target;
				break;
			case 20:
				comboBoxLocalIP = (System.Windows.Controls.ComboBox)target;
				break;
			case 21:
				label12 = (System.Windows.Controls.Label)target;
				break;
			case 22:
				groupBox4 = (System.Windows.Controls.GroupBox)target;
				break;
			case 23:
				buttonRefresh = (ImageButton)target;
				break;
			case 24:
				buttonPause = (ImageButton)target;
				break;
			case 25:
				buttonStop = (ImageButton)target;
				break;
			case 26:
				buttonResume = (ImageButton)target;
				break;
			case 27:
				listViewFileList = (System.Windows.Controls.ListView)target;
				listViewFileList.AddHandler(DragDrop.DropEvent, new System.Windows.DragEventHandler(listViewFileList_Drop));
				break;
			case 28:
				buttonPrint = (ImageButton)target;
				break;
			case 29:
				buttonDelete = (ImageButton)target;
				break;
			case 30:
				textBlockFileProgress = (TextBlock)target;
				break;
			case 31:
				buttonSendFile = (ImageButton)target;
				break;
			case 32:
				checkBoxCompressBeforeSend = (System.Windows.Controls.CheckBox)target;
				break;
			case 33:
				buttonExport = (ImageButton)target;
				break;
			case 34:
				手动 = (System.Windows.Controls.GroupBox)target;
				break;
			case 35:
				button_Y_plus = (ImageButton)target;
				break;
			case 36:
				button_E_plus = (ImageButton)target;
				break;
			case 37:
				button_Z_minus = (ImageButton)target;
				break;
			case 38:
				button_X_minus = (ImageButton)target;
				break;
			case 39:
				button_home = (ImageButton)target;
				break;
			case 40:
				button_X_plus = (ImageButton)target;
				break;
			case 41:
				button_E_minus = (ImageButton)target;
				break;
			case 42:
				button_Y_minus = (ImageButton)target;
				break;
			case 43:
				button_Z_plus = (ImageButton)target;
				break;
			case 44:
				button_10_mm = (ImageButton)target;
				break;
			case 45:
				button_1_mm = (ImageButton)target;
				break;
			case 46:
				button_0_1_mm = (ImageButton)target;
				break;
			case 47:
				sliderEndTemp = (Slider)target;
				sliderEndTemp.MouseLeftButtonUp += sliderEndTemp_MouseLeftButtonUp;
				sliderEndTemp.ValueChanged += sliderEndTemp_ValueChanged;
				break;
			case 48:
				label1 = (ImageLabel)target;
				break;
			case 49:
				textBlockEndTemp = (TextBlock)target;
				break;
			case 50:
				label2 = (ImageLabel)target;
				break;
			case 51:
				textBlockFanRatio = (TextBlock)target;
				break;
			case 52:
				sliderFanRatio = (Slider)target;
				sliderFanRatio.MouseLeftButtonUp += sliderFanRatio_MouseLeftButtonUp;
				sliderFanRatio.ValueChanged += sliderFanRatio_ValueChanged;
				break;
			case 53:
				sliderBedTemp = (Slider)target;
				sliderBedTemp.MouseLeftButtonUp += sliderBedTemp_MouseLeftButtonUp;
				sliderBedTemp.ValueChanged += sliderBedTemp_ValueChanged;
				break;
			case 54:
				label3 = (ImageLabel)target;
				break;
			case 55:
				textBlockBedTemp = (TextBlock)target;
				break;
			case 56:
				buttonEmergencyStop = (ImageButton)target;
				break;
			case 57:
				buttonCloseDevice = (ImageButton)target;
				break;
			case 58:
				buttonHelp = (ImageButton)target;
				break;
			case 59:
				groupBox2 = (System.Windows.Controls.GroupBox)target;
				break;
			case 60:
				label5 = (ImageLabel)target;
				break;
			case 61:
				label6 = (ImageLabel)target;
				break;
			case 62:
				label8 = (ImageLabel)target;
				break;
			case 63:
				label9 = (ImageLabel)target;
				break;
			case 64:
				textBoxLoacalSSid = (System.Windows.Controls.TextBox)target;
				break;
			case 65:
				textBoxLoacalSSidPassword = (PasswordBox)target;
				break;
			case 66:
				textBoxRouterSSid = (System.Windows.Controls.TextBox)target;
				break;
			case 67:
				textBoxRouterSSidPassword = (PasswordBox)target;
				break;
			case 68:
				buttonSetWifiHot = (ImageButton)target;
				break;
			case 69:
				buttonGenWifiHotConfig = (ImageButton)target;
				break;
			case 70:
				buttonSetRouterWifi = (ImageButton)target;
				break;
			case 71:
				buttonGenRouterWifiConfig = (ImageButton)target;
				break;
			case 72:
				label13 = (ImageLabel)target;
				break;
			case 73:
				textBoxDeviceName = (System.Windows.Controls.TextBox)target;
				break;
			case 74:
				buttonDeviceNameSet = (ImageButton)target;
				break;
			case 75:
				labelAuth = (ImageLabel)target;
				break;
			case 76:
				textBoxAuth = (System.Windows.Controls.TextBox)target;
				break;
			case 77:
				buttonSetAuth = (ImageButton)target;
				break;
			default:
				_contentLoaded = true;
				break;
			}
		}
	}
}
