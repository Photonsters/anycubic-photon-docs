Photon-S firmware v2.9.9

There are no official releases of this version from Anycubic. 

This is an unofficial backup copy of firmware v2.9.9 for the Anycubic Photon-S, obtained from Anycubic, provided to you courtesy of the Photonsters. 

This is the last good version that works with Chitubox, before the v3.4.1 update which broke it, and before the rushfixed v5.0.0 which restored Chitubox support but is buggy. 

Use at your own risk. We take no responsibility if the cake is a lie. 